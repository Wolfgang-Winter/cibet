Perfumery 1.0

  Perfumery is an example application for the Cibet control framework. It is 
  based on Cibet 0.5.1. For a detailed description what this application 
  demonstrates and how it works click the About menu item after installation of 
  perfumery.war.


Installation

  Perfumery example application is packed as a Maven project. You can just 
  import it into your development environment. The database scripts can be 
  found in the src/main/install folder. Adjust the scripts if another database
  than Derby is used. Change the database connection parameters in file
  src/main/resources/jndi.properties 
  and 
  src/main/resources/META-INF/persistence.xml.   
  
  Execute mvn install to create the application. Deploy the 
  perfumery.war file in your application server. It has been tested in 
  Jetty and Tomcat application servers. With Tomcat is is necessary to copy
  javaee-api-5.0.2.jar into the lib directory. This library can be found 
  in the local repository of the downloaded Maven files or in perfumery.war 
  archive. 
  
  Start the application with http://<your domain>/perfumery     
