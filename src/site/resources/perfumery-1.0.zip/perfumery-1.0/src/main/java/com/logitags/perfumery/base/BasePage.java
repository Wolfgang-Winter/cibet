/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.base;

import java.text.SimpleDateFormat;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.SessionState;

import com.logitags.perfumery.entities.LoginCredentials;
import com.logitags.perfumery.pages.Index;

/**
 *
 */
public abstract class BasePage {

   private static Logger log = Logger.getLogger(BasePage.class);

   @SessionState
   private LoginCredentials loginCredentials;
   private boolean loginCredentialsExists;

   @SessionState
   private EntityManager localEM;

   @InjectPage
   private Index index;

   private static SimpleDateFormat dateFormat = new SimpleDateFormat(
         "dd.MM.yyyy HH:mm:ss");

   public Object onActivate() {
      if (this.getClass().isInstance(index)) {
         log.debug("is Index page, skip");
         return null;
      }

      if (!isLoginCredentialsExists()) {
         return index;
      }

      return null;
   }

   public LoginCredentials getLoginCredentials() {
      return loginCredentials;
   }

   public boolean isLoginCredentialsExists() {
      return loginCredentialsExists;
   }

   /**
    * 
    * @return the localEM
    */
   public EntityManager getLocalEM() {
      return localEM;
   }

   /**
    * 
    * @param localEM
    *           the localEM to set
    */
   public void setLocalEM(EntityManager localEM) {
      this.localEM = localEM;
   }

   /**
    * @return the dateFormat
    */
   public SimpleDateFormat getDateFormat() {
      return dateFormat;
   }

}
