package com.logitags.perfumery.services;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.log4j.Logger;

import com.logitags.cibet.CibetContext;

/**
 *
 */
public class EJBPersistenceUnitInjector {

   /**
    * logger for tracing
    */
   private static Logger log = Logger
         .getLogger(EJBPersistenceUnitInjector.class);

   @AroundInvoke
   public Object inject(InvocationContext ctx) throws Exception {
      BaseEJBInterface ejb = (BaseEJBInterface) ctx.getTarget();
      log.debug("set EntityManager: EJB");
      CibetContext.setEntityManager(ejb.getEntityMananger());
      return ctx.proceed();
   }
}
