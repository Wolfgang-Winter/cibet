/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.logitags.cibet.ReleaseException;
import com.logitags.cibet.action.CibetEntityManager;
import com.logitags.cibet.action.CibetInterceptor;
import com.logitags.cibet.dc.ControlledObject;
import com.logitags.cibet.dc.DcManager;
import com.logitags.perfumery.entities.Order;

/**
 *
 */
@Stateless
@Local(OrderService.class)
@Interceptors( { EJBPersistenceUnitInjector.class, CibetInterceptor.class })
public class OrderServiceEJB implements OrderService, BaseEJBInterface {

   private static Logger log = Logger.getLogger(OrderServiceEJB.class);

   @PersistenceContext(unitName = "perfumesDB_EJB")
   private EntityManager eman;

   private EntityManager dc = new CibetEntityManager();

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.OrderService#getAllOrders(java.lang.String
    * )
    */
   public List<Order> getAllOrders(String company) {
      // EntityManager em = InitService.getEntityManager();
      Query query = dc.createNamedQuery(Order.SEL_ALL);
      query.setParameter("company", company);
      return query.getResultList();
   }

   public void createOrder(Order order) {
      // EntityManager em = InitService.getEntityManager();
      dc.persist(order);

      log.debug(order);
      File outDir = new File("OUT");
      outDir.mkdirs();
      File file = new File(outDir, order.getId() + "-" + order.getOrderId()
            + ".out");
      try {
         FileWriter out = new FileWriter(file);
         out.write(order.toString());
         out.close();
      } catch (IOException e) {
         log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      }
   }

   public Order getOrder(long id) {
      // EntityManager em = InitService.getEntityManager();
      return dc.find(Order.class, id);
   }

   /*
    * (non-Javadoc)
    * 
    * @see com.logitags.perfumery.services.BaseEJBInterface#getEntityMananger()
    */
   public EntityManager getEntityMananger() {
      return eman;
   }

   public void release(ControlledObject obj, String remark)
         throws ReleaseException {
      DcManager.release(obj, remark);
   }

   public void reject(ControlledObject obj, String remark) {
      DcManager.reject(obj, remark);
   }

}
