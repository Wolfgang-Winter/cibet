/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import javax.persistence.EntityManager;

/**
 *
 */
public interface BaseEJBInterface {

   /**
    * 
    * @return the eman
    */
   EntityManager getEntityMananger();
}
