package com.logitags.perfumery.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;

import com.logitags.cibet.action.UnapprovedEntityException;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Offer;
import com.logitags.perfumery.entities.Supplier;
import com.logitags.perfumery.pages.supplier.CreateSupplier;
import com.logitags.perfumery.services.SupplierService;

public class Suppliers extends BasePage {
   private static Logger log = Logger.getLogger(Perfumes.class);

   @InjectPage
   private CreateSupplier createSuppliersPage;

   @Property
   private Supplier supplier;

   @Persist
   private Supplier selectedSupplier;

   @Property
   private Offer offer;

   @Persist
   private String message;

   @Inject
   private SupplierService supplierService;

   public List<Supplier> getSuppliers() {
      log.info("loginCredentials company: "
            + getLoginCredentials().getCompany());
      return supplierService
            .getAllSuppliers(getLoginCredentials().getCompany());
   }

   void pageAttached() {
      if (createSuppliersPage.getOffers() != null) {
         createSuppliersPage.getOffers().clear();
      }
      if (createSuppliersPage.getPerfumes() != null) {
         log.debug("clear parfumes");
         createSuppliersPage.getPerfumes().clear();
      }
      createSuppliersPage.setSupplier(null);
   }

   void onActionFromShowOrders(long id) {
      selectedSupplier = supplierService.getSupplier(id);
      log.debug(selectedSupplier);
   }

   void onActionFromDelete(long id) {
      log.debug("delete supplier " + id);
      try {
         supplierService.delete(id);
      } catch (UnapprovedEntityException e) {
         log.error(e.getMessage(), e);
         message = "Delete failed: " + e.getMessage();
      }
      setSelectedSupplier(null);
   }

   /**
    * @return the selectedSupplier
    */
   public Supplier getSelectedSupplier() {
      if (selectedSupplier == null) {
         return new Supplier();
      } else {
         return selectedSupplier;
      }
   }

   /**
    * @param selectedSupplier
    *           the selectedSupplier to set
    */
   public void setSelectedSupplier(Supplier selectedSupplier) {
      this.selectedSupplier = selectedSupplier;
   }

   /**
    * @return the message
    */
   public String getMessage() {
      String m = message;
      message = "";
      return m;
   }

   /**
    * @param message
    *           the message to set
    */
   public void setMessage(String message) {
      this.message = message;
   }

}
