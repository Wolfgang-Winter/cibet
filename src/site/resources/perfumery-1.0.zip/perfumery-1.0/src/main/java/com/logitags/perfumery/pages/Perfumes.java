package com.logitags.perfumery.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ioc.annotations.Inject;

import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Perfume;
import com.logitags.perfumery.services.PerfumeService;

public class Perfumes extends BasePage {

   private static Logger log = Logger.getLogger(Perfumes.class);

   @Inject
   private PerfumeService perfumeService;

   public List<Perfume> getPerfumes() {
      log.info("loginCredentials company: "
            + getLoginCredentials().getCompany());
      return perfumeService.getAllPerfumes(getLoginCredentials().getCompany());
   }
}
