package com.logitags.perfumery.components;

import org.apache.log4j.Logger;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.Block;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Request;

import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.pages.Index;

/**
 * Layout component for pages of application perfumery.
 */
// @IncludeStylesheet("context:layout/layout.css")
public class Layout2 extends BasePage {

   private static Logger log = Logger.getLogger(Layout2.class);

   /** The page title, for the <title> element and the <h1>element. */
   @Property
   @Parameter(required = true, defaultPrefix = BindingConstants.LITERAL)
   private String title;

   @Property
   private String pageName;

   @Property
   private String context = "";

   @Property
   private String strippedPageName;

   @Property
   @Parameter(defaultPrefix = BindingConstants.LITERAL)
   private String sidebarTitle;

   @Property
   @Parameter(defaultPrefix = BindingConstants.LITERAL)
   private Block sidebar;

   @Inject
   private ComponentResources resources;

   @Inject
   private Request request;

   @InjectPage
   private Index index;

   public String getClassForPageName() {
      // log.debug("pagename=" + pageName);
      if ("Log off".equals(pageName)) {
         strippedPageName = "Index";
         context = pageName;
      } else {
         strippedPageName = pageName;
      }
      return resources.getPageName().equalsIgnoreCase(strippedPageName) ? "current_page_item"
            : null;
   }

   public String[] getPageNames() {
      return new String[] { "Perfumes", "Suppliers", "Orders", "Archives",
            "Release", "Config", "About" };
   }

   Object onActionFromLogOff() {
      request.getSession(true).invalidate();
      return index;
   }

}
