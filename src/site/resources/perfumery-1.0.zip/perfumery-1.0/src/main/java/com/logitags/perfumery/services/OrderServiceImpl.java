/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.apache.tapestry5.annotations.SessionState;

import com.logitags.cibet.ReleaseException;
import com.logitags.cibet.dc.ControlledObject;
import com.logitags.perfumery.entities.Order;

/**
 *
 */
public class OrderServiceImpl implements OrderService {

   private static Logger log = Logger.getLogger(OrderServiceImpl.class);

   @SessionState
   private EntityManager localEM;

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.OrderService#getAllOrders(java.lang.String
    * )
    */
   public List<Order> getAllOrders(String company) {
      EntityManager em = localEM;// InitService.getEntityManager();
      Query query = em.createNamedQuery(Order.SEL_ALL);
      query.setParameter("company", company);
      return query.getResultList();
   }

   public void createOrder(Order order) {
      EntityManager em = InitService.getEntityManager();
      em.getTransaction().begin();
      em.persist(order);

      log.debug(order);
      File outDir = new File("OUT");
      outDir.mkdirs();
      File file = new File(outDir, order.getId() + "-" + order.getOrderId()
            + ".out");
      try {
         FileWriter out = new FileWriter(file);
         out.write(order.toString());
         out.close();
         em.getTransaction().commit();
      } catch (IOException e) {
         log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      }
   }

   public Order getOrder(long id) {
      EntityManager em = InitService.getEntityManager();
      return em.find(Order.class, id);
   }

   public void release(ControlledObject obj, String remark)
         throws ReleaseException {

   }

   public void reject(ControlledObject obj, String remark) {

   }
}
