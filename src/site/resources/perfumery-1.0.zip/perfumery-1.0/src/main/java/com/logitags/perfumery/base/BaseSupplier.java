/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.base;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.util.AbstractSelectModel;

import com.logitags.perfumery.entities.Offer;
import com.logitags.perfumery.entities.Perfume;
import com.logitags.perfumery.entities.Supplier;
import com.logitags.perfumery.pages.Suppliers;
import com.logitags.perfumery.services.PerfumeService;
import com.logitags.perfumery.services.SupplierService;

/**
 *
 */
public class BaseSupplier extends BasePage {

   private class PerfumeSelectModel extends AbstractSelectModel {

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptionGroups()
       */
      public List<OptionGroupModel> getOptionGroups() {
         return new ArrayList<OptionGroupModel>();
      }

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptions()
       */
      public List<OptionModel> getOptions() {
         log.debug("getOptions");
         List<OptionModel> list = new ArrayList<OptionModel>();
         for (Perfume p : perfumes) {
            log.debug("add " + p);
            OptionModel model = new OptionModelImpl(p.getName(), p);
            list.add(model);
         }
         return list;
      }

   }

   private static Logger log = Logger.getLogger(BaseSupplier.class);

   @Persist
   private Supplier supplier;

   @InjectPage
   private Suppliers suppliersPage;

   @Inject
   private PerfumeService perfumeService;

   @Inject
   private SupplierService supplierService;

   @Persist
   private List<Perfume> perfumes;

   @Property
   private Perfume perfume;

   @Persist
   private List<Offer> offers;

   @Property
   private Offer offer;

   private int submitType = 0;

   @Component
   private Form form;

   @Property
   private final ValueEncoder<Offer> encoder = new ValueEncoder<Offer>() {
      public String toClient(Offer value) {
         return String.valueOf(value.getInternalId());
      }

      public Offer toValue(String key) {
         for (Offer of : offers) {
            log.debug("price:" + of.getPurchasePrice());
            if (String.valueOf(of.getInternalId()).equals(key)) {
               return of;
            }
         }
         log.debug("nothing found");
         return null;
      }
   };

   @Property
   private final ValueEncoder<Perfume> perfumeEncoder = new ValueEncoder<Perfume>() {
      public String toClient(Perfume value) {
         return String.valueOf(value.getId());
      }

      public Perfume toValue(String key) {
         for (Perfume pf : perfumes) {
            if (String.valueOf(pf.getId()).equals(key)) {
               return pf;
            }
         }
         log.debug("nothing found");
         return null;
      }
   };

   @Property
   private final SelectModel perfumeModel = new PerfumeSelectModel();

   void onSelectedFromAddOffer() {
      if (offers == null) {
         offers = new ArrayList<Offer>();
      }
      log.debug("offers size = " + offers.size());
      for (Offer of : offers) {
         log.debug(of.getPerfume().getName() + " price:"
               + of.getPurchasePrice());
      }
      Offer of = new Offer();
      of.setInternalId(offers.size() + 1);
      offers.add(of);
      submitType = 1;
   }

   void onSelectedFromCancel() {
      submitType = 2;
   }

   Object onActivate(long id) {
      Object returnPage = onActivate();
      if (returnPage != null) {
         return returnPage;
      }
      supplier = supplierService.getSupplier(id);
      offers = supplier.getOffers();
      for (Offer of : offers) {
         of.setInternalId(of.getId());
         log.debug(of.getPerfume().getName() + " price:"
               + of.getPurchasePrice());
      }
      return null;
   }

   void onActionFromRemove(long id) {
      for (Offer of : offers) {
         if (of.getId() == id) {
            offers.remove(of);
            break;
         }
      }
   }

   void pageAttached() {
      if (offers != null) {
         log.debug("offers size = " + offers.size());
      } else {
         log.debug("offers = null");
      }
      if (perfumes == null || perfumes.isEmpty()) {
         log.debug("load parfumes");
         perfumes = perfumeService.getAllPerfumes(getLoginCredentials()
               .getCompany());
      }
   }

   /**
    * @return the perfumes
    */
   public List<Perfume> getPerfumes() {
      return perfumes;
   }

   /**
    * @param perfumes
    *           the perfumes to set
    */
   public void setPerfumes(List<Perfume> perfumes) {
      this.perfumes = perfumes;
   }

   /**
    * @return the offers
    */
   public List<Offer> getOffers() {
      return offers;
   }

   /**
    * @param offers
    *           the offers to set
    */
   public void setOffers(List<Offer> offers) {
      this.offers = offers;
   }

   /**
    * @return the supplier
    */
   public Supplier getSupplier() {
      return supplier;
   }

   /**
    * @param supplier
    *           the supplier to set
    */
   public void setSupplier(Supplier supplier) {
      this.supplier = supplier;
   }

   /**
    * @return the suppliersPage
    */
   public Suppliers getSuppliersPage() {
      return suppliersPage;
   }

   /**
    * @param suppliersPage
    *           the suppliersPage to set
    */
   public void setSuppliersPage(Suppliers suppliersPage) {
      this.suppliersPage = suppliersPage;
   }

   /**
    * @return the submitType
    */
   public int getSubmitType() {
      return submitType;
   }

   /**
    * @param submitType
    *           the submitType to set
    */
   public void setSubmitType(int submitType) {
      this.submitType = submitType;
   }

   /**
    * @return the supplierService
    */
   public SupplierService getSupplierService() {
      return supplierService;
   }

   /**
    * @param supplierService
    *           the supplierService to set
    */
   public void setSupplierService(SupplierService supplierService) {
      this.supplierService = supplierService;
   }

   /**
    * @return the form
    */
   public Form getForm() {
      return form;
   }

   /**
    * @param form
    *           the form to set
    */
   public void setForm(Form form) {
      this.form = form;
   }
}
