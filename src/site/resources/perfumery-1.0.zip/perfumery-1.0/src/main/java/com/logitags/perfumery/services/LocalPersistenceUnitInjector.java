package com.logitags.perfumery.services;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.log4j.Logger;

/**
 *
 */
public class LocalPersistenceUnitInjector {

   /**
    * logger for tracing
    */
   private static Logger log = Logger
         .getLogger(LocalPersistenceUnitInjector.class);

   @AroundInvoke
   public Object inject(InvocationContext ctx) throws Exception {
      InitService.getEntityManager();
      return ctx.proceed();
   }
}
