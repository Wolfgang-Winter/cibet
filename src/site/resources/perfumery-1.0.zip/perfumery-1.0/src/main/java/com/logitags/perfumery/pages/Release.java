/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Retain;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;

import com.logitags.cibet.dc.ControlledObject;
import com.logitags.cibet.dc.DataModificationControlledObject;
import com.logitags.cibet.dc.DcManager;
import com.logitags.cibet.dc.MethodInvocationControlledObject;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.pages.release.ShowDataModificationDetails;
import com.logitags.perfumery.pages.release.ShowMethodInvocationDetails;

/**
 *
 */
public class Release extends BasePage {

   private static Logger log = Logger.getLogger(Release.class);

   @Property
   private ControlledObject co;

   @InjectPage
   private ShowMethodInvocationDetails methodPage;

   @InjectPage
   private ShowDataModificationDetails dataPage;

   @Inject
   private BeanModelSource beanModelSource;

   @Inject
   private ComponentResources componentResources;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<ControlledObject> controlledObjectModel;

   void setupRender() {

      if (controlledObjectModel == null) {
         controlledObjectModel = beanModelSource.createDisplayModel(
               ControlledObject.class, componentResources.getMessages());

         controlledObjectModel.get("editUserId").label("User");
         controlledObjectModel.include("caseId", "controlAction",
               "controlScheme", "editDate", "editUserId", "objectClass");
      }
   }

   public List<ControlledObject> getControlledObjects() {
      return DcManager.findUnreleased();
   }

   Object onActionFromShowDetails(long id) {
      log.debug(id);
      co = this.getLocalEM().find(ControlledObject.class, id);
      if (co instanceof MethodInvocationControlledObject) {
         methodPage.setControlledObject((MethodInvocationControlledObject) co);
         return methodPage;
      } else {
         dataPage.setControlledObject((DataModificationControlledObject) co);
         return dataPage;
      }
   }

}
