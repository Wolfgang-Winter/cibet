package com.logitags.perfumery.pages.archive;

import java.lang.annotation.Annotation;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.PropertyConduit;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Retain;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;

import com.logitags.cibet.archive.DataModificationArchive;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Offer;
import com.logitags.perfumery.entities.Supplier;

/**
 *
 */
public class ShowDataModificationDetails extends BasePage {

   /**
    * logger for tracing
    */
   private static Logger log = Logger
         .getLogger(ShowDataModificationDetails.class);

   public class PerfumeNameConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         return ((Offer) obj).getPerfume().getName();
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         ((Offer) obj).getPerfume().setName((String) value);
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   @Inject
   private BeanModelSource beanModelSource;

   @Inject
   private ComponentResources componentResources;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<Offer> offerModel;

   @Persist
   private DataModificationArchive archive;

   private static SimpleDateFormat dateFormat = new SimpleDateFormat(
         "dd.MM.yyyy HH:mm:ss");

   void setupRender() {
      if (offerModel == null) {
         offerModel = beanModelSource.createDisplayModel(Offer.class,
               componentResources.getMessages());
         offerModel.add("perfume", new PerfumeNameConduit());
         offerModel.include("perfume", "purchasePrice");
      }
   }

   /**
    * 
    * @return the archive
    */
   public DataModificationArchive getArchive() {
      return archive;
   }

   /**
    * 
    * @param archive
    *           the archive to set
    */
   public void setArchive(DataModificationArchive archive) {
      this.archive = archive;
   }

   public Supplier getSupplier() {
      return (Supplier) archive.getObject();
   }

}
