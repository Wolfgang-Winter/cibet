/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.pages.supplier;

import org.apache.log4j.Logger;

import com.logitags.cibet.action.UnapprovedEntityException;
import com.logitags.perfumery.base.BaseSupplier;
import com.logitags.perfumery.entities.Offer;

/**
 *
 */
public class CreateSupplier extends BaseSupplier {

   private static Logger log = Logger.getLogger(CreateSupplier.class);

   Object onSuccess() {
      log.debug("submitType=" + getSubmitType());
      if (getSubmitType() == 1) {
         return null;
      } else if (getSubmitType() == 2) {
         return getSuppliersPage();
      }

      if (getOffers() == null || getSupplier() == null) return null;

      for (Offer of : getOffers()) {
         of.setSupplier(getSupplier());
         log.debug(of.getPerfume().getName() + " price:"
               + of.getPurchasePrice());
      }
      getSupplier().setOffers(getOffers());
      getSupplier().setCompany(this.getLoginCredentials().getCompany());
      try {
         getSupplierService().persist(getSupplier());
      } catch (UnapprovedEntityException e) {
         getForm().recordError("Create Supplier failed: " + e.getMessage());
      }

      return getSuppliersPage();
   }

}
