/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

/**
 *
 */
public enum CibetScheme {

   ARCHIVE, FOUR_EYES, SIX_EYES
}
