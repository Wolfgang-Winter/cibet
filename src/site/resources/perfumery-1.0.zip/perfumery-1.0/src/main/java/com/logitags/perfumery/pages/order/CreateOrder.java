/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.pages.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.Translator;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.TranslatorSource;
import org.apache.tapestry5.util.AbstractSelectModel;

import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Offer;
import com.logitags.perfumery.entities.Order;
import com.logitags.perfumery.entities.OrderItem;
import com.logitags.perfumery.entities.Perfume;
import com.logitags.perfumery.entities.Supplier;
import com.logitags.perfumery.pages.Orders;
import com.logitags.perfumery.services.InitService;
import com.logitags.perfumery.services.OrderService;
import com.logitags.perfumery.services.PerfumeService;
import com.logitags.perfumery.services.SupplierService;

/**
 *
 */
public class CreateOrder extends BasePage {

   private class PerfumeSelectModel extends AbstractSelectModel {

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptionGroups()
       */
      public List<OptionGroupModel> getOptionGroups() {
         return new ArrayList<OptionGroupModel>();
      }

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptions()
       */
      public List<OptionModel> getOptions() {
         log.debug("getOptions");
         List<OptionModel> list = new ArrayList<OptionModel>();
         if (supplier == null) {
            log.warn("supplier is null");
            return list;
         }
         for (Offer o : supplier.getOffers()) {
            Perfume p = o.getPerfume();
            log.debug("add " + p);
            OptionModel model = new OptionModelImpl(p.getName() + " ["
                  + o.getPurchasePrice() + "�]", p);
            list.add(model);
         }
         return list;
      }

   }

   @Inject
   private TranslatorSource transSource;

   public Translator<Date> getDateTranslator() {
      return transSource.findByType(Date.class);
   }

   private class OfferSelectModel extends AbstractSelectModel {

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptionGroups()
       */
      public List<OptionGroupModel> getOptionGroups() {
         return new ArrayList<OptionGroupModel>();
      }

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptions()
       */
      public List<OptionModel> getOptions() {
         log.debug("getOfferOptions");
         List<OptionModel> list = new ArrayList<OptionModel>();
         if (supplier == null) {
            log.warn("supplier is null");
            return list;
         }
         for (Offer o : supplier.getOffers()) {
            Perfume p = o.getPerfume();
            log.debug("add " + p);
            OptionModel model = new OptionModelImpl(p.getName() + " ["
                  + o.getPurchasePrice() + "�]", o);
            list.add(model);
         }
         return list;
      }
   }

   @Property
   private final SelectModel perfumeModel = new PerfumeSelectModel();

   @Property
   private final SelectModel offerModel = new OfferSelectModel();

   @Property
   private final ValueEncoder<Perfume> perfumeEncoder = new ValueEncoder<Perfume>() {
      public String toClient(Perfume value) {
         return String.valueOf(value.getId());
      }

      public Perfume toValue(String key) {
         for (Perfume pf : perfumes) {
            if (String.valueOf(pf.getId()).equals(key)) {
               return pf;
            }
         }
         log.debug("nothing found");
         return null;
      }
   };

   private class SupplierSelectModel extends AbstractSelectModel {

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptionGroups()
       */
      public List<OptionGroupModel> getOptionGroups() {
         return new ArrayList<OptionGroupModel>();
      }

      /*
       * (non-Javadoc)
       * 
       * @see org.apache.tapestry5.SelectModel#getOptions()
       */
      public List<OptionModel> getOptions() {
         log.debug("getOptions");
         List<OptionModel> list = new ArrayList<OptionModel>();
         for (Supplier s : suppliers) {
            log.debug("add " + s);
            OptionModel model = new OptionModelImpl(s.getName(), s);
            list.add(model);
         }
         return list;
      }

   }

   private static Logger log = Logger.getLogger(CreateOrder.class);

   @Persist
   private Order order;

   @InjectPage
   private Orders ordersPage;

   @Persist
   private Date currentDate;

   @Persist
   private Supplier supplier;

   @Property
   private Offer offer;

   @Persist
   private List<Supplier> suppliers;

   @Inject
   private PerfumeService perfumeService;

   @Inject
   private OrderService orderService;

   @Inject
   private SupplierService supplierService;

   @Persist
   private List<Perfume> perfumes;

   @Property
   private Perfume perfume;

   @Persist
   private List<OrderItem> orderItems;

   @Property
   private OrderItem orderItem;

   private int submitType = 0;

   @Property
   private String hidEventValue;

   @Property
   private final ValueEncoder<OrderItem> itemEncoder = new ValueEncoder<OrderItem>() {
      public String toClient(OrderItem value) {
         return String.valueOf(value.getInternalId());
      }

      public OrderItem toValue(String key) {
         for (OrderItem oi : orderItems) {
            if (String.valueOf(oi.getInternalId()).equals(key)) {
               return oi;
            }
         }
         log.debug("nothing found");
         return null;
      }
   };

   @Property
   private final ValueEncoder<Offer> offerEncoder = new ValueEncoder<Offer>() {
      public String toClient(Offer value) {
         return String.valueOf(value.getId());
      }

      public Offer toValue(String key) {
         for (Offer o : supplier.getOffers()) {
            if (String.valueOf(o.getId()).equals(key)) {
               log.debug("found: " + o);
               return o;
            }
         }
         log.debug("nothing found");
         return null;
      }
   };

   @Property
   private final ValueEncoder<Supplier> supplierEncoder = new ValueEncoder<Supplier>() {
      public String toClient(Supplier value) {
         return String.valueOf(value.getId());
      }

      public Supplier toValue(String key) {
         for (Supplier su : suppliers) {
            if (String.valueOf(su.getId()).equals(key)) {
               return su;
            }
         }
         log.debug("nothing found");
         return null;
      }
   };

   @Property
   private final SelectModel supplierModel = new SupplierSelectModel();

   void onSelectedFromAddOrderItem() {
      if (orderItems == null) {
         orderItems = new ArrayList<OrderItem>();
      }
      log.debug("orderItems size = " + orderItems.size());
      for (OrderItem oi : orderItems) {
         if (oi.getOffer() != null) {
            log.debug(oi.getOffer().getPerfume().getName() + " price:"
                  + oi.getPrice());
         }
         log.debug("quantity = " + oi.getQuantity());
      }
      OrderItem oi = new OrderItem();
      oi.setOrder(order);
      oi.setInternalId(orderItems.size() + 1);
      orderItems.add(oi);
      submitType = 1;
   }

   void onSelectedFromCancel() {
      submitType = 2;
   }

   void pageAttached() {
      if (currentDate == null) currentDate = new Date();
      if (orderItems != null) {
         log.debug("offers size = " + orderItems.size());
      } else {
         log.debug("orderItems = null");
      }
      if (perfumes == null || perfumes.isEmpty()) {
         log.debug("load parfumes");
         perfumes = perfumeService.getAllPerfumes(getLoginCredentials()
               .getCompany());
      }

      suppliers = supplierService.getAllSuppliers(getLoginCredentials()
            .getCompany());
   }

   Object onSuccess() {
      log.debug("submitType=" + submitType);

      if (orderItems != null) {
         log.debug("orderItems size = " + orderItems.size());
         double total = 0;
         for (OrderItem item : orderItems) {
            if (item.getOffer() != null) {
               item.setPrice(item.getOffer().getPurchasePrice()
                     * item.getQuantity());
               total += item.getPrice();
            }
         }
         log.debug("total = " + total);
         order.setTotalPrice(total);
      }

      if (submitType == 1) {
         return null;
      } else if (submitType == 2) {
         return ordersPage;
      }

      log.debug("hidEventValue=" + hidEventValue);
      if ("changeSupplier".equals(hidEventValue)) {
         hidEventValue = "";
         order = null;
         orderItems = null;
         currentDate = new Date();
      }

      if (orderItems == null || order == null) return null;

      order.setOrderItems(orderItems);
      order.setCompany(this.getLoginCredentials().getCompany());
      order.setOrderDate(currentDate);
      order.setSupplier(supplier);

      try {
         Context ctx = InitService.getInitialContext();
         OrderService service = (OrderService) ctx
               .lookup("OrderServiceEJBLocal");
         service.createOrder(order);
      } catch (NamingException e) {
         log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      }
      return ordersPage;
   }

   /**
    * @return the perfumes
    */
   public List<Perfume> getPerfumes() {
      return perfumes;
   }

   /**
    * @param perfumes
    *           the perfumes to set
    */
   public void setPerfumes(List<Perfume> perfumes) {
      this.perfumes = perfumes;
   }

   /**
    * @return the OrderItems
    */
   public List<OrderItem> getOrderItems() {
      return orderItems;
   }

   /**
    * @param OrderItems
    *           the OrderItems to set
    */
   public void setOrderItems(List<OrderItem> orderItems) {
      this.orderItems = orderItems;
   }

   /**
    * @return the order
    */
   public Order getOrder() {
      return order;
   }

   /**
    * @param order
    *           the order to set
    */
   public void setOrder(Order order) {
      this.order = order;
   }

   /**
    * @return the currentDate
    */
   public Date getCurrentDate() {
      return currentDate;
   }

   /**
    * @param currentDate
    *           the currentDate to set
    */
   public void setCurrentDate(Date currentDate) {
      this.currentDate = currentDate;
   }

   /**
    * @param supplier
    *           the supplier to set
    */
   public void setSupplier(Supplier supplier) {
      this.supplier = supplier;
      log.debug("set new Supplier");
   }

   /**
    * @return the supplier
    */
   public Supplier getSupplier() {
      return supplier;
   }

}
