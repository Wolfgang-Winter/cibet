/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.pages;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.util.EnumSelectModel;
import org.apache.tapestry5.util.EnumValueEncoder;

import com.logitags.cibet.CibetContext;
import com.logitags.cibet.ConfigurationManager;
import com.logitags.cibet.ControlAction;
import com.logitags.cibet.ControlConfiguration;
import com.logitags.cibet.SchemeController;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.CibetScheme;
import com.logitags.perfumery.entities.Configuration;
import com.logitags.perfumery.entities.Supplier;
import com.logitags.perfumery.services.InitService;
import com.logitags.perfumery.services.OrderServiceEJB;

/**
 *
 */
public class Config extends BasePage {

   private static Logger log = Logger.getLogger(Config.class);

   @Inject
   private ComponentResources componentResources;

   @Persist
   private String message;

   @Persist
   @Property
   private List<CibetScheme> insertSupplierSchemes;

   @Persist
   @Property
   private List<CibetScheme> updateSupplierSchemes;

   @Persist
   @Property
   private List<CibetScheme> deleteSupplierSchemes;

   @Persist
   @Property
   private List<CibetScheme> persistSupplierSchemes;

   @Persist
   @Property
   private List<CibetScheme> invokeCreateOrderSchemes;

   @Inject
   private Messages _messages;

   private final ValueEncoder<CibetScheme> schemeEncoder = new EnumValueEncoder<CibetScheme>(
         CibetScheme.class);

   private final SelectModel schemeModel = new EnumSelectModel(
         CibetScheme.class, _messages);

   /**
    * @return the schemeEncoder
    */
   public ValueEncoder<CibetScheme> getSchemeEncoder() {
      return schemeEncoder;
   }

   /**
    * @return the schemeModel
    */
   public SelectModel getSchemeModel() {
      return schemeModel;
   }

   void pageAttached() {
      log.debug("Config pageAttached");

      insertSupplierSchemes = new ArrayList<CibetScheme>();
      ControlConfiguration c = ConfigurationManager
            .getDataControlConfiguration(Supplier.class.getName(),
                  ControlAction.INSERT, CibetContext.getOwner());
      for (SchemeController controller : c.getSchemeControllers()) {
         insertSupplierSchemes.add(CibetScheme.valueOf(controller
               .getSchemeName()));
      }

      deleteSupplierSchemes = new ArrayList<CibetScheme>();
      c = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.DELETE, CibetContext.getOwner());
      for (SchemeController controller : c.getSchemeControllers()) {
         deleteSupplierSchemes.add(CibetScheme.valueOf(controller
               .getSchemeName()));
      }

      persistSupplierSchemes = new ArrayList<CibetScheme>();
      c = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.PERSIST, CibetContext.getOwner());
      for (SchemeController controller : c.getSchemeControllers()) {
         persistSupplierSchemes.add(CibetScheme.valueOf(controller
               .getSchemeName()));
      }

      updateSupplierSchemes = new ArrayList<CibetScheme>();
      c = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.UPDATE, CibetContext.getOwner());
      for (SchemeController controller : c.getSchemeControllers()) {
         updateSupplierSchemes.add(CibetScheme.valueOf(controller
               .getSchemeName()));
      }

      invokeCreateOrderSchemes = new ArrayList<CibetScheme>();
      c = ConfigurationManager.getMethodControlConfiguration(
            OrderServiceEJB.class.getName(), "createOrder", CibetContext
                  .getOwner());
      for (SchemeController controller : c.getSchemeControllers()) {
         invokeCreateOrderSchemes.add(CibetScheme.valueOf(controller
               .getSchemeName()));
      }
   }

   Object onSuccess() {
      log.debug("onSuccess");
      log.debug("size: " + insertSupplierSchemes.size());
      message = "";

      List<Configuration> clist = new ArrayList<Configuration>();

      new ConfigurationManager().stop();

      if (!deleteSupplierSchemes.isEmpty()) {
         Configuration c = new Configuration();
         clist.add(c);
         c.setOwner(CibetContext.getOwner());
         c.setAction(ControlAction.DELETE);
         StringBuffer b = new StringBuffer();
         String[] schemes = new String[deleteSupplierSchemes.size()];
         for (int i = 0; i < deleteSupplierSchemes.size(); i++) {
            schemes[i] = deleteSupplierSchemes.get(i).name();
            b.append(",");
            b.append(schemes[i]);
         }
         c.setSchemes(b.toString().substring(1));
         ConfigurationManager.configure(Supplier.class, ControlAction.DELETE,
               schemes);
      }
      if (!insertSupplierSchemes.isEmpty()) {
         Configuration c = new Configuration();
         clist.add(c);
         c.setOwner(CibetContext.getOwner());
         c.setAction(ControlAction.INSERT);
         StringBuffer b = new StringBuffer();
         String[] schemes = new String[insertSupplierSchemes.size()];
         for (int i = 0; i < insertSupplierSchemes.size(); i++) {
            schemes[i] = insertSupplierSchemes.get(i).name();
            b.append(",");
            b.append(schemes[i]);
         }
         c.setSchemes(b.toString().substring(1));
         ConfigurationManager.configure(Supplier.class, ControlAction.INSERT,
               schemes);
      }
      if (!persistSupplierSchemes.isEmpty()) {
         Configuration c = new Configuration();
         clist.add(c);
         c.setOwner(CibetContext.getOwner());
         c.setAction(ControlAction.PERSIST);
         StringBuffer b = new StringBuffer();
         String[] schemes = new String[persistSupplierSchemes.size()];
         for (int i = 0; i < persistSupplierSchemes.size(); i++) {
            schemes[i] = persistSupplierSchemes.get(i).name();
            b.append(",");
            b.append(schemes[i]);
         }
         c.setSchemes(b.toString().substring(1));
         ConfigurationManager.configure(Supplier.class, ControlAction.PERSIST,
               schemes);
      }
      if (!updateSupplierSchemes.isEmpty()) {
         Configuration c = new Configuration();
         clist.add(c);
         c.setOwner(CibetContext.getOwner());
         c.setAction(ControlAction.UPDATE);
         StringBuffer b = new StringBuffer();
         String[] schemes = new String[updateSupplierSchemes.size()];
         for (int i = 0; i < updateSupplierSchemes.size(); i++) {
            schemes[i] = updateSupplierSchemes.get(i).name();
            b.append(",");
            b.append(schemes[i]);
         }
         c.setSchemes(b.toString().substring(1));
         ConfigurationManager.configure(Supplier.class, ControlAction.UPDATE,
               schemes);
      }
      if (!invokeCreateOrderSchemes.isEmpty()) {
         Configuration c = new Configuration();
         clist.add(c);
         c.setOwner(CibetContext.getOwner());
         c.setAction(ControlAction.INVOKE);
         StringBuffer b = new StringBuffer();
         String[] schemes = new String[invokeCreateOrderSchemes.size()];
         for (int i = 0; i < invokeCreateOrderSchemes.size(); i++) {
            schemes[i] = invokeCreateOrderSchemes.get(i).name();
            b.append(",");
            b.append(schemes[i]);
         }
         c.setSchemes(b.toString().substring(1));
         ConfigurationManager.configure(OrderServiceEJB.class, "createOrder",
               schemes);
      }

      // control
      String owner = this.getLoginCredentials().getCompany();
      ControlConfiguration cc = ConfigurationManager
            .getDataControlConfiguration(Supplier.class.getName(),
                  ControlAction.DELETE, owner);
      log.debug("DELETE: " + cc);
      cc = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.INSERT, owner);
      log.debug("INSERT: " + cc);
      cc = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.PERSIST, owner);
      log.debug("PERSIST: " + cc);
      cc = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.UPDATE, owner);
      log.debug("UPDATE: " + cc);
      cc = ConfigurationManager.getMethodControlConfiguration(
            OrderServiceEJB.class.getName(), "createOrder", owner);
      log.debug("INVOKE: " + cc);

      // save
      EntityManager em = InitService.getEntityManager();
      em.getTransaction().begin();
      Query q = em
            .createQuery("DELETE FROM Configuration WHERE owner = :owner");
      q.setParameter("owner", CibetContext.getOwner());
      int count = q.executeUpdate();
      log.debug(count + " Configurations deleted");

      for (Configuration conf : clist) {
         em.persist(conf);
      }

      em.getTransaction().commit();

      message = "Configuration applied successfully";
      return null;
   }

   /**
    * @return the message
    */
   public String getMessage() {
      String m = message;
      message = "";
      return m;
   }

   /**
    * @param message
    *           the message to set
    */
   public void setMessage(String message) {
      this.message = message;
   }

}
