package com.logitags.perfumery.pages;

import com.logitags.perfumery.base.BasePage;

/**
 * Start page of application perfumery.
 */
public class Home extends BasePage {

}
