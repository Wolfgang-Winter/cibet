/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

import com.logitags.cibet.action.CibetEntityManager;
import com.logitags.perfumery.entities.Supplier;

/**
 *
 */
@Stateless
@Local(SupplierService.class)
@Interceptors( { EJBPersistenceUnitInjector.class })
public class SupplierServiceEJB implements SupplierService, BaseEJBInterface {

   private static Logger log = Logger.getLogger(SupplierServiceEJB.class);

   @PersistenceContext(unitName = "perfumesDB_EJB")
   private EntityManager eman;

   private EntityManager dc = new CibetEntityManager();

   /*
    * (non-Javadoc)
    * 
    * @see com.logitags.perfumery.services.SupplierService#delete(long)
    */
   public void delete(long id) {
      // TODO Auto-generated method stub

   }

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.SupplierService#getAllSuppliers(java.lang
    * .String)
    */
   public List<Supplier> getAllSuppliers(String company) {
      // TODO Auto-generated method stub
      return null;
   }

   /*
    * (non-Javadoc)
    * 
    * @see com.logitags.perfumery.services.SupplierService#getSupplier(long)
    */
   public Supplier getSupplier(long id) {
      // TODO Auto-generated method stub
      return null;
   }

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.SupplierService#persist(com.logitags.perfumery
    * .entities.Supplier)
    */
   public void persist(Supplier supplier) {
      // TODO Auto-generated method stub

   }

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.SupplierService#update(com.logitags.perfumery
    * .entities.Supplier)
    */
   public void update(Supplier supplier) {
      log.debug(supplier);
      dc.merge(supplier);
   }

   /*
    * (non-Javadoc)
    * 
    * @see com.logitags.perfumery.services.BaseEJBInterface#getEntityMananger()
    */
   public EntityManager getEntityMananger() {
      return eman;
   }

}
