/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.pages.supplier;

import javax.ejb.EJBException;
import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.logitags.perfumery.base.BaseSupplier;
import com.logitags.perfumery.entities.Offer;
import com.logitags.perfumery.services.InitService;
import com.logitags.perfumery.services.SupplierService;

/**
 *
 */
public class EditSupplier extends BaseSupplier {

   private static Logger log = Logger.getLogger(EditSupplier.class);

   Object onSuccess() {
      log.debug("submitType=" + getSubmitType());
      if (getSubmitType() == 1) {
         return null;
      } else if (getSubmitType() == 2) {
         return getSuppliersPage();
      }

      if (getOffers() == null || getSupplier() == null) return null;

      for (Offer of : getOffers()) {
         of.setSupplier(getSupplier());
         log.debug(of.getPerfume().getName() + " price:"
               + of.getPurchasePrice());
      }
      getSupplier().setOffers(getOffers());

      try {
         Context ctx = InitService.getInitialContext();
         SupplierService service = (SupplierService) ctx
               .lookup("SupplierServiceEJBLocal");
         service.update(getSupplier());
      } catch (NamingException e) {
         log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      } catch (EJBException e) {
         log.error(e.getMessage());
         Throwable ne = e.getCause();
         getForm().recordError("Update failed: " + ne.getMessage());
         return null;
      }

      getSuppliersPage().setSelectedSupplier(null);
      return getSuppliersPage();
   }

}
