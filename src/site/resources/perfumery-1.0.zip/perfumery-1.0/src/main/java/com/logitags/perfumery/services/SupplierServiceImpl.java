/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.logitags.cibet.action.UnapprovedEntityException;
import com.logitags.perfumery.entities.Supplier;

/**
 *
 */
public class SupplierServiceImpl implements SupplierService {

   private static Logger log = Logger.getLogger(SupplierServiceImpl.class);

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.SupplierService#persist(com.logitags.perfumery
    * .entities.Supplier)
    */
   public void persist(Supplier supplier) {
      log.debug("start persisting");
      EntityManager em = InitService.getEntityManager();
      em.getTransaction().begin();
      em.persist(supplier);
      em.getTransaction().commit();
   }

   public List<Supplier> getAllSuppliers(String company) {
      EntityManager em = InitService.getEntityManager();
      Query query = em.createNamedQuery(Supplier.SEL_ALL);
      query.setParameter("company", company);
      return query.getResultList();
   }

   public Supplier getSupplier(long id) {
      EntityManager em = InitService.getEntityManager();
      return em.find(Supplier.class, id);
   }

   /*
    * (non-Javadoc)
    * 
    * @see com.logitags.perfumery.services.SupplierService#delete(long)
    */
   public void delete(long id) {
      EntityManager em = InitService.getEntityManager();
      em.getTransaction().begin();
      Supplier s = em.find(Supplier.class, id);
      try {
         em.remove(s);
         em.getTransaction().commit();
      } catch (UnapprovedEntityException e) {
         log.error(e.getMessage(), e);
         em.getTransaction().rollback();
         throw e;
      }
   }

   /*
    * (non-Javadoc)
    * 
    * @see
    * com.logitags.perfumery.services.SupplierService#update(com.logitags.perfumery
    * .entities.Supplier)
    */
   public void update(Supplier supplier) {
      EntityManager em = InitService.getEntityManager();
      em.getTransaction().begin();
      log.debug(supplier);
      em.merge(supplier);
      log.debug(supplier);
      em.getTransaction().commit();
   }
}
