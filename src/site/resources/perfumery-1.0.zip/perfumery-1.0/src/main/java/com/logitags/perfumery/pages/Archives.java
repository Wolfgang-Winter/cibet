/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.pages;

import java.lang.annotation.Annotation;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.PropertyConduit;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Retain;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;

import com.logitags.cibet.archive.Archive;
import com.logitags.cibet.archive.ArchiveManager;
import com.logitags.cibet.archive.DataModificationArchive;
import com.logitags.cibet.archive.MethodInvocationArchive;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.pages.archive.ShowDataModificationDetails;
import com.logitags.perfumery.pages.archive.ShowMethodInvocationDetails;
import com.logitags.perfumery.services.InitService;

/**
 *
 */
public class Archives extends BasePage {

   private static Logger log = Logger.getLogger(Archives.class);

   public class ObjectIdConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         if (obj instanceof DataModificationArchive) {
            return ((DataModificationArchive) obj).getObjectId();
         } else {
            return "-";
         }
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         if (obj instanceof DataModificationArchive) {
            ((DataModificationArchive) obj).setObjectId((String) value);
         }
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   public class DateConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         Archive a = (Archive) obj;
         return InitService.getDateFormat().format(a.getCreateDate());
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         throw new RuntimeException("not implemented");
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   public class MethodNameConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         if (obj instanceof MethodInvocationArchive) {
            return ((MethodInvocationArchive) obj).getMethodName();
         } else {
            return "-";
         }
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         if (obj instanceof MethodInvocationArchive) {
            ((MethodInvocationArchive) obj).setMethodName((String) value);
         }
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   @Inject
   private BeanModelSource beanModelSource;

   @Inject
   private ComponentResources componentResources;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<Archive> archiveModel;

   @Property
   private Archive archive;

   @InjectPage
   private ShowMethodInvocationDetails methodPage;

   @InjectPage
   private ShowDataModificationDetails dataPage;

   void setupRender() {

      if (archiveModel == null) {
         archiveModel = beanModelSource.createDisplayModel(Archive.class,
               componentResources.getMessages());

         archiveModel.add("objectId", new ObjectIdConduit());
         archiveModel.add("methodName", new MethodNameConduit());
         archiveModel.add("date", new DateConduit());
         archiveModel.get("createUserId").label("User");
         archiveModel.include("caseId", "controlEvent", "date", "createUserId",
               "objectClass", "objectId", "methodName");
      }
   }

   public List<Archive> getArchives() {
      return ArchiveManager.loadArchives();
   }

   Object onActionFromShowDetails(long id) {
      log.debug(id);
      archive = this.getLocalEM().find(Archive.class, id);
      if (archive instanceof MethodInvocationArchive) {
         methodPage.setArchive((MethodInvocationArchive) archive);
         return methodPage;
      } else {
         dataPage.setArchive((DataModificationArchive) archive);
         return dataPage;
      }
   }
}
