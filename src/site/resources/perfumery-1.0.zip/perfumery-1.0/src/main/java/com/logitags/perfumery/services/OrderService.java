/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.util.List;

import com.logitags.cibet.ReleaseException;
import com.logitags.cibet.dc.ControlledObject;
import com.logitags.perfumery.entities.Order;

/**
 *
 */
public interface OrderService {

   List<Order> getAllOrders(String company);

   void createOrder(Order order);

   Order getOrder(long id);

   void release(ControlledObject obj, String remark) throws ReleaseException;

   void reject(ControlledObject obj, String remark);
}
