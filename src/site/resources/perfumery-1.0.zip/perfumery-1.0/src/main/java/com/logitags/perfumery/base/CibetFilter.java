/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.base;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.logitags.cibet.CibetContext;
import com.logitags.perfumery.entities.LoginCredentials;

/**
 *
 */
public class CibetFilter implements Filter {

   private static Logger log = Logger.getLogger(CibetFilter.class);

   /*
    * (non-Javadoc)
    * 
    * @see javax.servlet.Filter#destroy()
    */
   public void destroy() {
   }

   /*
    * (non-Javadoc)
    * 
    * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
    * javax.servlet.ServletResponse, javax.servlet.FilterChain)
    */
   public void doFilter(ServletRequest request, ServletResponse response,
         FilterChain chain) throws IOException, ServletException {
      log.debug("enter CibetFilter");
      HttpSession session = ((HttpServletRequest) request).getSession();
      EntityManager em = (EntityManager) session
            .getAttribute("sso:javax.persistence.EntityManager");
      if (em != null) {
         log.debug("set EntityManager " + em);
         CibetContext.setEntityManager(em);
      }
      LoginCredentials cred = (LoginCredentials) session
            .getAttribute("sso:com.logitags.perfumery.entities.LoginCredentials");
      if (cred != null) {
         if (cred.getCompany() != null) {
            log.debug("set " + cred.getCompany());
            CibetContext.setOwner(cred.getCompany());
         }
         log.debug("set " + cred.getUsername());
         CibetContext.setUserId(cred.getUsername());
      }

      chain.doFilter(request, response);
   }

   /*
    * (non-Javadoc)
    * 
    * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
    */
   public void init(FilterConfig arg0) throws ServletException {
   }

}
