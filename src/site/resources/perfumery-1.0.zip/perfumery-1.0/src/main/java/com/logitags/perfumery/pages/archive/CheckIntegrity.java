package com.logitags.perfumery.pages.archive;

import org.apache.log4j.Logger;
import org.apache.tapestry5.annotations.Property;
import org.hibernate.ejb.EntityManagerImpl;

import com.logitags.cibet.CibetContext;
import com.logitags.cibet.archive.ArchiveManager;
import com.logitags.cibet.archive.IntegrityCheck;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.services.InitService;

/**
 *
 */
public class CheckIntegrity extends BasePage {

   /**
    * logger for tracing
    */
   private static Logger log = Logger.getLogger(CheckIntegrity.class);

   @Property
   private IntegrityCheck check;

   public Object onActivate() {
      EntityManagerImpl em = (EntityManagerImpl) CibetContext
            .getEntityManager();
      em.getSession().clear();

      InitService.getEntityManager().getTransaction().begin();
      check = ArchiveManager.checkArchiveIntegrity();
      InitService.getEntityManager().getTransaction().commit();
      return null;
   }

}
