/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;

import com.logitags.cibet.action.CibetEntityManager;

/**
 *
 */
public class InitService {

   private static Logger log = Logger.getLogger(InitService.class);

   private static EntityManagerFactory emFactory;

   private static Context context;

   private static SimpleDateFormat dateFormat = new SimpleDateFormat(
         "yyyy/MM/dd HH:mm:ss");

   public static void init() {
      emFactory = Persistence.createEntityManagerFactory("perfumesDB");
   }

   public static EntityManager getEntityManager() {
      return new CibetEntityManager();
   }

   public static Context getInitialContext() {
      if (context == null) {
         log.info("initialise InitialContext");
         Properties properties = new Properties();
         InputStream in = Thread.currentThread().getContextClassLoader()
               .getResourceAsStream("jndi.properties");

         log.debug("in = " + in);
         if (in != null) {
            try {
               properties.load(in);
               for (Object key : properties.keySet()) {
                  log.debug(key + "=" + properties.get(key));
               }

            } catch (IOException e) {
               log.error(e.getMessage(), e);
               throw new RuntimeException(e);
            }
         }

         // Properties properties = new Properties();
         // properties.setProperty(Context.INITIAL_CONTEXT_FACTORY,
         // "org.apache.openejb.client.LocalInitialContextFactory");
         //
         // properties.put("myDataSource", "new://Resource?type=DataSource");
         // properties.put("myDataSource.JdbcDriver",
         // "org.apache.derby.jdbc.ClientDriver");
         // properties.put("myDataSource.JdbcUrl",
         // "jdbc:derby://localhost:1527/perfumes;create=true");
         // properties.put("myDataSource.JtaManaged", "true");
         // properties.put("myDataSource.UserName", "APP");
         // properties.put("myDataSource.Password", "x");
         //
         // properties.put("myDataSourceUnmanaged",
         // "new://Resource?type=DataSource");
         // properties.put("myDataSourceUnmanaged.JdbcDriver",
         // "org.apache.derby.jdbc.ClientDriver");
         // properties.put("myDataSourceUnmanaged.JdbcUrl",
         // "jdbc:derby://localhost:1527/perfumes;create=true");
         // properties.put("myDataSourceUnmanaged.JtaManaged", "false");
         // properties.put("myDataSourceUnmanaged.UserName", "APP");
         // properties.put("myDataSourceUnmanaged.Password", "x");
         try {
            context = new InitialContext(properties);
            // context = new InitialContext();
            Hashtable<?, ?> props = context.getEnvironment();
            for (Object key : props.keySet()) {
               log.debug(key + "=" + props.get(key));
            }

         } catch (NamingException e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException(e);
         }
      }
      return context;
   }

   /**
    * 
    * @return the emFac
    */
   public static EntityManagerFactory getEmFactory() {
      return emFactory;
   }

   /**
    * @return the dateFormat
    */
   public static SimpleDateFormat getDateFormat() {
      return dateFormat;
   }
}
