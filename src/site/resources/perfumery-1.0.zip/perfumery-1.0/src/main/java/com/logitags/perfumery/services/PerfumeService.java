/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.util.List;

import com.logitags.perfumery.entities.Perfume;

/**
 *
 */
public interface PerfumeService {

   List<Perfume> getAllPerfumes(String company);
}
