/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import org.apache.tapestry5.beaneditor.NonVisual;
import org.hibernate.annotations.Cascade;

/**
 *
 */
@Entity
@NamedQueries( { @NamedQuery(name = Supplier.SEL_ALL, query = "SELECT a FROM Supplier a WHERE company = :company") })
public class Supplier implements Serializable {

   public static final String SEL_ALL = "SUPPLIER_SEL_ALL";

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @NonVisual
   private Long id;

   private String name;

   private String address;

   @NonVisual
   private String company;

   @OneToMany(cascade = { CascadeType.ALL }, mappedBy = "supplier")
   @Cascade( { org.hibernate.annotations.CascadeType.DELETE_ORPHAN })
   private List<Offer> offers = new ArrayList<Offer>();

   public String toString() {
      StringBuffer b = new StringBuffer();
      b.append(name);
      b.append(", ");
      b.append(id);
      b.append(", ");
      b.append(address);
      b.append(", ");
      b.append(offers.size());
      return b.toString();
   }

   /**
    * @return the id
    */
   public Long getId() {
      return id;
   }

   /**
    * @param id
    *           the id to set
    */
   public void setId(Long id) {
      this.id = id;
   }

   /**
    * @return the name
    */
   public String getName() {
      return name;
   }

   /**
    * @param name
    *           the name to set
    */
   public void setName(String name) {
      this.name = name;
   }

   /**
    * @return the address
    */
   public String getAddress() {
      return address;
   }

   /**
    * @param address
    *           the address to set
    */
   public void setAddress(String address) {
      this.address = address;
   }

   /**
    * @return the company
    */
   public String getCompany() {
      return company;
   }

   /**
    * @param company
    *           the company to set
    */
   public void setCompany(String company) {
      this.company = company;
   }

   /**
    * @return the offers
    */
   public List<Offer> getOffers() {
      return offers;
   }

   /**
    * @param offers
    *           the offers to set
    */
   public void setOffers(List<Offer> offers) {
      this.offers = offers;
   }

}
