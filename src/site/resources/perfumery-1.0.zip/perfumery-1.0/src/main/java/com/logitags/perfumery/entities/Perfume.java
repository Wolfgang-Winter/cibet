/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.apache.tapestry5.beaneditor.NonVisual;

/**
 *
 */
@Entity
@NamedQueries( { @NamedQuery(name = Perfume.SEL_ALL, query = "SELECT a FROM Perfume a WHERE company = :company") })
public class Perfume implements Serializable {

   public static final String SEL_ALL = "PERFUME_SEL_ALL";

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @NonVisual
   private Long id;

   private String name;

   private double sellingPrice;

   private String type;

   @NonVisual
   private String company;

   /**
    * @return the id
    */
   public Long getId() {
      return id;
   }

   /**
    * @param id
    *           the id to set
    */
   public void setId(Long id) {
      this.id = id;
   }

   /**
    * @return the name
    */
   public String getName() {
      return name;
   }

   /**
    * @param name
    *           the name to set
    */
   public void setName(String name) {
      this.name = name;
   }

   /**
    * @return the price
    */
   public double getSellingPrice() {
      return sellingPrice;
   }

   /**
    * @param price
    *           the price to set
    */
   public void setSellingPrice(double price) {
      this.sellingPrice = price;
   }

   /**
    * @return the type
    */
   public String getType() {
      return type;
   }

   /**
    * @param type
    *           the type to set
    */
   public void setType(String type) {
      this.type = type;
   }

   /**
    * @return the company
    */
   public String getCompany() {
      return company;
   }

   /**
    * @param company
    *           the company to set
    */
   public void setCompany(String company) {
      this.company = company;
   }

}
