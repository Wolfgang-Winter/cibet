/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.tapestry5.beaneditor.NonVisual;

/**
 *
 */
@Entity
@Table(name = "order_")
@NamedQueries( { @NamedQuery(name = Order.SEL_ALL, query = "SELECT a FROM Order a WHERE company = :company") })
public class Order implements Serializable {

   public static final String SEL_ALL = "ORDER_SEL_ALL";

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @NonVisual
   private Long id;

   private String orderId;

   private Date orderDate = new Date();

   private double totalPrice;

   @OneToMany(cascade = { CascadeType.ALL }, mappedBy = "order")
   private List<OrderItem> orderItems = new ArrayList<OrderItem>();

   @ManyToOne
   private Supplier supplier;

   @NonVisual
   private String company;

   public String toString() {
      StringBuffer b = new StringBuffer();
      b.append("Order ");
      b.append(orderId);
      b.append(" (");
      b.append(orderDate);
      b.append(")\n");
      b.append("Supplier: ");
      b.append(supplier.getName());
      b.append("  TotalPrice: ");
      b.append(totalPrice);
      b.append("\n");
      for (OrderItem item : orderItems) {
         b.append(item);
         b.append("\n");
      }
      b.append("<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>");
      return b.toString();
   }

   /**
    * @return the id
    */
   public Long getId() {
      return id;
   }

   /**
    * @param id
    *           the id to set
    */
   public void setId(Long id) {
      this.id = id;
   }

   /**
    * @return the orderDate
    */
   public Date getOrderDate() {
      return orderDate;
   }

   /**
    * @param orderDate
    *           the orderDate to set
    */
   public void setOrderDate(Date orderDate) {
      this.orderDate = orderDate;
   }

   /**
    * @return the totalPrice
    */
   public double getTotalPrice() {
      return totalPrice;
   }

   /**
    * @param totalPrice
    *           the totalPrice to set
    */
   public void setTotalPrice(double totalPrice) {
      this.totalPrice = totalPrice;
   }

   /**
    * @return the orderItems
    */
   public List<OrderItem> getOrderItems() {
      return orderItems;
   }

   /**
    * @param orderItems
    *           the orderItems to set
    */
   public void setOrderItems(List<OrderItem> orderItems) {
      this.orderItems = orderItems;
   }

   /**
    * @return the supplier
    */
   public Supplier getSupplier() {
      return supplier;
   }

   /**
    * @param supplier
    *           the supplier to set
    */
   public void setSupplier(Supplier supplier) {
      this.supplier = supplier;
   }

   /**
    * @return the company
    */
   public String getCompany() {
      return company;
   }

   /**
    * @param company
    *           the company to set
    */
   public void setCompany(String company) {
      this.company = company;
   }

   /**
    * @return the orderId
    */
   public String getOrderId() {
      return orderId;
   }

   /**
    * @param orderId
    *           the orderId to set
    */
   public void setOrderId(String orderId) {
      this.orderId = orderId;
   }

}
