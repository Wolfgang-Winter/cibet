package com.logitags.perfumery.pages.archive;

import java.lang.annotation.Annotation;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.PropertyConduit;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Retain;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;

import com.logitags.cibet.archive.MethodInvocationArchive;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Order;
import com.logitags.perfumery.entities.OrderItem;

/**
 *
 */
public class ShowMethodInvocationDetails extends BasePage {

   /**
    * logger for tracing
    */
   private static Logger log = Logger
         .getLogger(ShowMethodInvocationDetails.class);

   public class SupplierNameConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         return ((Order) obj).getSupplier().getName();
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         ((Order) obj).getSupplier().setName((String) value);
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   public class PerfumeNameConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         return ((OrderItem) obj).getOffer().getPerfume().getName();
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         ((OrderItem) obj).getOffer().getPerfume().setName((String) value);
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   @Inject
   private BeanModelSource beanModelSource;

   @Inject
   private ComponentResources componentResources;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<Order> orderModel;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<OrderItem> orderItemModel;

   @Persist
   private MethodInvocationArchive archive;

   void setupRender() {

      if (orderModel == null) {
         orderModel = beanModelSource.createDisplayModel(Order.class,
               componentResources.getMessages());
         orderModel.add("supplier", new SupplierNameConduit());
         orderModel.include("orderId", "orderDate", "totalPrice", "supplier");
      }
      if (orderItemModel == null) {
         orderItemModel = beanModelSource.createDisplayModel(OrderItem.class,
               componentResources.getMessages());
         orderItemModel.add("perfume", new PerfumeNameConduit());
         orderItemModel.include("perfume", "price", "quantity");
      }
   }

   /**
    * 
    * @return the archive
    */
   public MethodInvocationArchive getArchive() {
      return archive;
   }

   /**
    * 
    * @param archive
    *           the archive to set
    */
   public void setArchive(MethodInvocationArchive archive) {
      this.archive = archive;
   }

   public Order getOrder() {
      if (archive.getMethodParamValues().length > 0) {
         return (Order) archive.getMethodParamValues()[0];
      } else {
         return null;
      }
   }

   public String getParameterType() {
      if (archive.getMethodParamTypes().length > 0) {
         return archive.getMethodParamTypes()[0].getName();
      } else {
         return "";
      }
   }

}
