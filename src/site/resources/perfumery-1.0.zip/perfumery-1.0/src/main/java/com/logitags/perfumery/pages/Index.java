package com.logitags.perfumery.pages;

import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.RequestGlobals;

import com.logitags.cibet.CibetContext;
import com.logitags.cibet.ConfigurationManager;
import com.logitags.cibet.ControlAction;
import com.logitags.cibet.ControlConfiguration;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Configuration;
import com.logitags.perfumery.entities.Supplier;
import com.logitags.perfumery.services.InitService;
import com.logitags.perfumery.services.OrderServiceEJB;

/**
 * Start page of application perfumery.
 */
public class Index extends BasePage {

   private static Logger log = Logger.getLogger(Index.class);

   @InjectPage
   private Home home;

   @Inject
   private RequestGlobals requestGlobals;

   @Component
   private Form loginForm;

   Object onSuccess() {
      log.info("context: " + requestGlobals.getRequest().getContextPath());
      log.info("path: " + requestGlobals.getRequest().getPath());

      CibetContext.setUserId(getLoginCredentials().getUsername());
      setLocalEM(InitService.getEmFactory().createEntityManager());
      log.debug("set EntityManager: Index");
      CibetContext.setEntityManager(getLocalEM());

      if ("Hugo".equals(getLoginCredentials().getUsername())
            || "Harry".equals(getLoginCredentials().getUsername())
            || "Herman".equals(getLoginCredentials().getUsername())) {
         getLoginCredentials().setCompany("Goudlas");
         getLoginCredentials().setCss("/perfumery/layout/layout.css");
         CibetContext.setOwner("Goudlas");
      } else if ("Amy".equals(getLoginCredentials().getUsername())
            || "Anne".equals(getLoginCredentials().getUsername())
            || "Arabella".equals(getLoginCredentials().getUsername())) {
         getLoginCredentials().setCompany("Rives Yocher");
         getLoginCredentials().setCss("/perfumery/layout/layout2.css");
         CibetContext.setOwner("Rives Yocher");
      } else {
         loginForm.recordError("Allowed users are: "
               + "Hugo, Harry, Herman [Goudlas] and "
               + "Amy, Anne, Arabella [Rives Yocher]");
         return null;
      }

      loadConfigurations();
      return home;
   }

   void pageLoaded() {
      log.info("pageLoaded called");

      // HttpSession session =
      // requestGlobals.getHTTPServletRequest().getSession();
      // Enumeration<String> e = session.getAttributeNames();
      // while (e.hasMoreElements()) {
      // String name = e.nextElement();
      // log.info(name + ": " + session.getAttribute(name));
      // }

      System.setProperty("openejb.logger.external", "true");
      InitService.init();
   }

   private void loadConfigurations() {
      new ConfigurationManager().stop();
      Query q = InitService.getEntityManager().createQuery(
            "SELECT a FROM Configuration a WHERE owner = :owner");
      q.setParameter("owner", CibetContext.getOwner());
      List<Configuration> list = q.getResultList();
      for (Configuration conf : list) {
         switch (conf.getAction()) {
         case DELETE:
            ConfigurationManager.configure(Supplier.class,
                  ControlAction.DELETE, conf.getSchemeNames());
            break;
         case INSERT:
            ConfigurationManager.configure(Supplier.class,
                  ControlAction.INSERT, conf.getSchemeNames());
            break;
         case PERSIST:
            ConfigurationManager.configure(Supplier.class,
                  ControlAction.PERSIST, conf.getSchemeNames());
            break;
         case UPDATE:
            ConfigurationManager.configure(Supplier.class,
                  ControlAction.UPDATE, conf.getSchemeNames());
            break;
         case INVOKE:
            ConfigurationManager.configure(OrderServiceEJB.class,
                  "createOrder", conf.getSchemeNames());
         }
      }

      // control
      String owner = this.getLoginCredentials().getCompany();
      ControlConfiguration cc = ConfigurationManager
            .getDataControlConfiguration(Supplier.class.getName(),
                  ControlAction.DELETE, owner);
      log.debug("DELETE: " + cc);
      cc = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.INSERT, owner);
      log.debug("INSERT: " + cc);
      cc = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.PERSIST, owner);
      log.debug("PERSIST: " + cc);
      cc = ConfigurationManager.getDataControlConfiguration(Supplier.class
            .getName(), ControlAction.UPDATE, owner);
      log.debug("UPDATE: " + cc);
      cc = ConfigurationManager.getMethodControlConfiguration(
            OrderServiceEJB.class.getName(), "createOrder", owner);
      log.debug("INVOKE: " + cc);

   }

}
