/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.apache.tapestry5.beaneditor.NonVisual;

/**
 *
 */
@Entity
public class OrderItem implements Serializable {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @NonVisual
   private Long id;

   @Transient
   @NonVisual
   private long internalId;

   @ManyToOne
   private Order order;

   @ManyToOne
   private Offer offer;

   private int quantity;

   private double price;

   public String toString() {
      StringBuffer b = new StringBuffer();
      b.append(id);
      b.append(":: ");
      b.append(offer.getPerfume().getId());
      b.append(" [");
      b.append(offer.getPerfume().getName());
      b.append("] ");
      b.append(offer.getPurchasePrice());
      b.append(" ");
      b.append(quantity);
      b.append(" ");
      b.append(price);
      return b.toString();
   }

   /**
    * @return the id
    */
   public Long getId() {
      return id;
   }

   /**
    * @param id
    *           the id to set
    */
   public void setId(Long id) {
      this.id = id;
   }

   /**
    * @return the order
    */
   public Order getOrder() {
      return order;
   }

   /**
    * @param order
    *           the order to set
    */
   public void setOrder(Order order) {
      this.order = order;
   }

   /**
    * @return the Offer
    */
   public Offer getOffer() {
      return offer;
   }

   /**
    * @param Offer
    *           the Offer to set
    */
   public void setOffer(Offer offer) {
      this.offer = offer;
   }

   /**
    * @return the quantity
    */
   public int getQuantity() {
      return quantity;
   }

   /**
    * @param quantity
    *           the quantity to set
    */
   public void setQuantity(int quantity) {
      this.quantity = quantity;
   }

   /**
    * @return the price
    */
   public double getPrice() {
      return price;
   }

   /**
    * @param price
    *           the price to set
    */
   public void setPrice(double price) {
      this.price = price;
   }

   /**
    * @return the internalId
    */
   public long getInternalId() {
      return internalId;
   }

   /**
    * @param internalId
    *           the internalId to set
    */
   public void setInternalId(long internalId) {
      this.internalId = internalId;
   }
}
