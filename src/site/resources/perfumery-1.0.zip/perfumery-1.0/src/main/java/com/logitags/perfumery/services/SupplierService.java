/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.util.List;

import com.logitags.perfumery.entities.Supplier;

/**
 *
 */
public interface SupplierService {

   void persist(Supplier supplier);

   void update(Supplier supplier);

   List<Supplier> getAllSuppliers(String company);

   Supplier getSupplier(long id);

   void delete(long id);
}
