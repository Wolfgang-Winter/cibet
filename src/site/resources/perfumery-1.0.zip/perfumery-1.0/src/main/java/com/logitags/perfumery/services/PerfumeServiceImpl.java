/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.logitags.perfumery.entities.Perfume;

/**
 *
 */
public class PerfumeServiceImpl implements PerfumeService {

   public List<Perfume> getAllPerfumes(String company) {
      EntityManager em = InitService.getEntityManager();
      Query query = em.createNamedQuery(Perfume.SEL_ALL);
      query.setParameter("company", company);
      return query.getResultList();
   }
}
