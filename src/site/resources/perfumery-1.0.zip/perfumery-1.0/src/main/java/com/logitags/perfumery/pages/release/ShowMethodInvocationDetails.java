package com.logitags.perfumery.pages.release;

import java.lang.annotation.Annotation;

import javax.naming.Context;

import org.apache.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.PropertyConduit;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Retain;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;

import com.logitags.cibet.dc.MethodInvocationControlledObject;
import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Order;
import com.logitags.perfumery.entities.OrderItem;
import com.logitags.perfumery.pages.Release;
import com.logitags.perfumery.services.InitService;
import com.logitags.perfumery.services.OrderService;

/**
 *
 */
public class ShowMethodInvocationDetails extends BasePage {

   /**
    * logger for tracing
    */
   private static Logger log = Logger
         .getLogger(ShowMethodInvocationDetails.class);

   public class SupplierNameConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         return ((Order) obj).getSupplier().getName();
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         ((Order) obj).getSupplier().setName((String) value);
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   public class PerfumeNameConduit implements PropertyConduit {

      /**
       * @see org.apache.tapestry5.PropertyConduit#get(java.lang.Object)
       * @param arg0
       * @return
       */
      public Object get(Object obj) {
         return ((OrderItem) obj).getOffer().getPerfume().getName();
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#getPropertyType()
       * @return
       */
      public Class getPropertyType() {
         return String.class;
      }

      /**
       * @see org.apache.tapestry5.PropertyConduit#set(java.lang.Object,
       *      java.lang.Object)
       * @param arg0
       * @param arg1
       */
      public void set(Object obj, Object value) {
         ((OrderItem) obj).getOffer().getPerfume().setName((String) value);
      }

      /**
       * @see org.apache.tapestry5.ioc.AnnotationProvider#getAnnotation(java.lang.Class)
       * @param <T>
       * @param arg0
       * @return
       */
      public <T extends Annotation> T getAnnotation(Class<T> arg0) {
         return null;
      }
   }

   @Inject
   private BeanModelSource beanModelSource;

   @Inject
   private ComponentResources componentResources;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<Order> orderModel;

   @SuppressWarnings("unchecked")
   @Property
   @Retain
   private BeanModel<OrderItem> orderItemModel;

   @Persist
   private MethodInvocationControlledObject controlledObject;

   @Property
   private String remark;

   @Component
   private Form form;

   @InjectPage
   private Release releasePage;

   void setupRender() {

      if (orderModel == null) {
         orderModel = beanModelSource.createDisplayModel(Order.class,
               componentResources.getMessages());
         orderModel.add("supplier", new SupplierNameConduit());
         orderModel.include("orderId", "orderDate", "totalPrice", "supplier");
      }
      if (orderItemModel == null) {
         orderItemModel = beanModelSource.createDisplayModel(OrderItem.class,
               componentResources.getMessages());
         orderItemModel.add("perfume", new PerfumeNameConduit());
         orderItemModel.include("perfume", "price", "quantity");
      }
   }

   /**
    * 
    * @return the archive
    */
   public MethodInvocationControlledObject getControlledObject() {
      return controlledObject;
   }

   /**
    * 
    * @param archive
    *           the archive to set
    */
   public void setControlledObject(MethodInvocationControlledObject co) {
      this.controlledObject = co;
   }

   public Order getOrder() {
      return (Order) controlledObject.getMethodParamValues()[0];
   }

   public String getParameterType() {
      return controlledObject.getMethodParamTypes()[0].getName();
   }

   void onSelectedFromReject() {
      log.debug("reject " + controlledObject);
      try {
         Context ctx = InitService.getInitialContext();
         OrderService service = (OrderService) ctx
               .lookup("OrderServiceEJBLocal");
         service.reject(controlledObject, remark);
      } catch (Exception e) {
         log.error(e.getMessage(), e);
         form.recordError("Reject failed: " + e.getMessage());
      }
   }

   void onSelectedFromRelease() {
      log.debug("release " + controlledObject);
      try {
         Context ctx = InitService.getInitialContext();
         OrderService service = (OrderService) ctx
               .lookup("OrderServiceEJBLocal");
         service.release(controlledObject, remark);
      } catch (Exception e) {
         log.error(e.getMessage(), e);
         form.recordError("Release failed: " + e.getMessage());
      }
   }

   Object onSuccess() {
      if (form.getHasErrors()) return null;
      return releasePage;
   }
}
