/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.apache.tapestry5.beaneditor.NonVisual;

/**
 *
 */
@Entity
public class Offer implements Serializable {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @NonVisual
   private Long id;

   @Transient
   @NonVisual
   private long internalId;

   @ManyToOne
   private Supplier supplier;

   @ManyToOne
   private Perfume perfume;

   private double purchasePrice;

   public String toString() {
      StringBuffer b = new StringBuffer();
      b.append("id: ");
      b.append(id);
      b.append(", perfume: ");
      b.append(perfume != null ? perfume.getName() : null);
      b.append(", supplier: ");
      b.append(supplier != null ? supplier.getName() : null);
      return b.toString();
   }

   /**
    * @return the id
    */
   public Long getId() {
      return id;
   }

   /**
    * @param id
    *           the id to set
    */
   public void setId(Long id) {
      this.id = id;
   }

   /**
    * @return the supplier
    */
   public Supplier getSupplier() {
      return supplier;
   }

   /**
    * @param supplier
    *           the supplier to set
    */
   public void setSupplier(Supplier supplier) {
      this.supplier = supplier;
   }

   /**
    * @return the perfume
    */
   public Perfume getPerfume() {
      return perfume;
   }

   /**
    * @param perfume
    *           the perfume to set
    */
   public void setPerfume(Perfume perfume) {
      this.perfume = perfume;
   }

   /**
    * @return the price
    */
   public double getPurchasePrice() {
      return purchasePrice;
   }

   /**
    * @param price
    *           the price to set
    */
   public void setPurchasePrice(double price) {
      this.purchasePrice = price;
   }

   /**
    * @return the internalId
    */
   public long getInternalId() {
      return internalId;
   }

   /**
    * @param internalId
    *           the internalId to set
    */
   public void setInternalId(long internalId) {
      this.internalId = internalId;
   }
}
