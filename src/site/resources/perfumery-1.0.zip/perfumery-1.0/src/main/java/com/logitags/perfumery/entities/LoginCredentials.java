/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import org.apache.tapestry5.beaneditor.NonVisual;

/**
 *
 */
public class LoginCredentials {

   private String username;

   private String password;

   @NonVisual
   private String company;

   @NonVisual
   private String css;

   /**
    * @return the username
    */
   public String getUsername() {
      return username;
   }

   /**
    * @param username
    *           the username to set
    */
   public void setUsername(String username) {
      this.username = username;
   }

   /**
    * @return the password
    */
   public String getPassword() {
      return password;
   }

   /**
    * @param password
    *           the password to set
    */
   public void setPassword(String password) {
      this.password = password;
   }

   /**
    * @return the company
    */
   public String getCompany() {
      return company;
   }

   /**
    * @param company
    *           the company to set
    */
   public void setCompany(String company) {
      this.company = company;
   }

   /**
    * @return the css
    */
   public String getCss() {
      return css;
   }

   /**
    * @param css
    *           the css to set
    */
   public void setCss(String css) {
      this.css = css;
   }

}
