package com.logitags.perfumery.pages;

import java.util.List;

import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;

import com.logitags.perfumery.base.BasePage;
import com.logitags.perfumery.entities.Order;
import com.logitags.perfumery.entities.OrderItem;
import com.logitags.perfumery.pages.order.CreateOrder;
import com.logitags.perfumery.services.InitService;
import com.logitags.perfumery.services.OrderService;

public class Orders extends BasePage {
   private static Logger log = Logger.getLogger(Perfumes.class);

   @Inject
   private OrderService orderService;

   @InjectPage
   private CreateOrder createOrderPage;

   @Persist
   private Order selectedOrder;

   @Property
   private Order order;

   @Property
   private OrderItem item;

   public List<Order> getOrders() {
      try {
         Context ctx = InitService.getInitialContext();
         OrderService service = (OrderService) ctx
               .lookup("OrderServiceEJBLocal");
         return service.getAllOrders(getLoginCredentials().getCompany());
      } catch (NamingException e) {
         log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      }
   }

   void onActionFromShowOrderItems(long id) {
      try {
         Context ctx = InitService.getInitialContext();
         OrderService service = (OrderService) ctx
               .lookup("OrderServiceEJBLocal");
         selectedOrder = service.getOrder(id);
      } catch (NamingException e) {
         log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      }
      log.debug(selectedOrder);
   }

   void pageAttached() {
      createOrderPage.setCurrentDate(null);

      if (createOrderPage.getOrderItems() != null) {
         createOrderPage.getOrderItems().clear();
      }
      if (createOrderPage.getPerfumes() != null) {
         log.debug("clear parfumes");
         createOrderPage.getPerfumes().clear();
      }
      createOrderPage.setOrder(null);

   }

   /**
    * @return the selectedOrder
    */
   public Order getSelectedOrder() {
      if (selectedOrder == null) {
         return new Order();
      } else {
         return selectedOrder;
      }
   }

   /**
    * @param selectedOrder
    *           the selectedOrder to set
    */
   public void setSelectedOrder(Order selectedOrder) {
      this.selectedOrder = selectedOrder;
   }

}
