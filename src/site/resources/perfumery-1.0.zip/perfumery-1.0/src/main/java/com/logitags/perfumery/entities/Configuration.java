/*
 *******************************************************************************
 * L O G I T A G S
 * Software and Programming
 * Dr. Wolfgang Winter
 * Germany
 *
 * All rights reserved
 *
 *******************************************************************************
 */
/**
 * 
 */
package com.logitags.perfumery.entities;

import java.util.StringTokenizer;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.apache.log4j.Logger;
import org.apache.tapestry5.beaneditor.NonVisual;

import com.logitags.cibet.ControlAction;

/**
 *
 */
@Entity
public class Configuration {

   private static Logger log = Logger.getLogger(Configuration.class);

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @NonVisual
   private Long id;

   private String owner;

   @Enumerated(EnumType.STRING)
   private ControlAction action;

   private String schemes;

   /**
    * @return the id
    */
   public Long getId() {
      return id;
   }

   /**
    * @param id
    *           the id to set
    */
   public void setId(Long id) {
      this.id = id;
   }

   /**
    * @return the owner
    */
   public String getOwner() {
      return owner;
   }

   /**
    * @param owner
    *           the owner to set
    */
   public void setOwner(String owner) {
      this.owner = owner;
   }

   /**
    * @return the action
    */
   public ControlAction getAction() {
      return action;
   }

   /**
    * @param action
    *           the action to set
    */
   public void setAction(ControlAction action) {
      this.action = action;
   }

   /**
    * @return the schemes
    */
   public String getSchemes() {
      return schemes;
   }

   /**
    * @param schemes
    *           the schemes to set
    */
   public void setSchemes(String schemes) {
      this.schemes = schemes;
   }

   public String[] getSchemeNames() {
      if (schemes == null) return new String[] {};
      StringTokenizer tok = new StringTokenizer(schemes, ",");
      String[] array = new String[tok.countTokens()];
      int i = 0;
      while (tok.hasMoreTokens()) {
         array[i] = tok.nextToken();
         log.debug("add scheme " + array[i]);
         i++;
      }
      return array;
   }
}
