DELETE FROM perfume;
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Civet No 5', 44, 'Perfume', 'Goudlas');
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Canal No 1', 61, 'Perfume', 'Goudlas');
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Fresh Air', 22, 'Eau de Toilette', 'Goudlas');			
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Emil', 34, 'Eau de Toilette', 'Goudlas');
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Kopi Luwak Essentiels', 49, 'Eau de Toilette', 'Goudlas');


	
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Civet No 5', 47, 'Perfume', 'Rives Yocher');
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Artemis', 44, 'Perfume', 'Rives Yocher');
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Emil', 33, 'Eau de Toilette', 'Rives Yocher');
INSERT INTO perfume (name, sellingprice, type, company) VALUES
	('Kopi Luwak Essentiels', 51, 'Eau de Toilette', 'Rives Yocher');
									