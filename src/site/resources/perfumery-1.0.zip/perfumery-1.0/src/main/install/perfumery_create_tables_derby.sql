--DROP TABLE orderitem;
--DROP TABLE offer;
--DROP TABLE order_;
--DROP TABLE supplier;
--DROP TABLE perfume;
--DROP TABLE configuration;

CREATE TABLE supplier(
   id                BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   company           VARCHAR(50)    NOT NULL,
   name              VARCHAR(50)    NOT NULL,
   address           VARCHAR(255)    NOT NULL,
   PRIMARY KEY(id)
);

CREATE TABLE perfume(
   id                BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   company           VARCHAR(50)    NOT NULL,
   name              VARCHAR(50)    NOT NULL,
   type              VARCHAR(50)    NOT NULL,
   sellingprice      DOUBLE         NOT NULL,
   PRIMARY KEY(id)
);

CREATE TABLE offer(
   id                BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   purchaseprice     DOUBLE         NOT NULL,
   perfume_id        BIGINT         NOT NULL,
   supplier_id       BIGINT         NOT NULL,
   PRIMARY KEY(id)
);

CREATE TABLE order_(
   id                BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   company           VARCHAR(50)    NOT NULL,
   orderid           VARCHAR(50)    NOT NULL,
   orderdate         TIMESTAMP      NOT NULL,
   totalprice        DOUBLE         NOT NULL,
   supplier_id       BIGINT         NOT NULL,
   PRIMARY KEY(id)
);

CREATE TABLE orderitem(
   id                BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   quantity          INTEGER        NOT NULL,
   offer_id          BIGINT         NOT NULL,
   order_id          BIGINT         NOT NULL,
   price             DOUBLE         NOT NULL,
   PRIMARY KEY(id)
);

CREATE TABLE configuration(
   id                BIGINT         NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   action            VARCHAR(50)    NOT NULL,
   owner             VARCHAR(50)    NOT NULL,
   schemes           VARCHAR(255)   NOT NULL,
   PRIMARY KEY(id)
);
